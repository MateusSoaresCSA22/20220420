﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex10_lista
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            double valordolar; 
            double valorcotacao;
            double resultado;
            Console.WriteLine("Exercício 10"); Console.WriteLine("");
            Console.Write("Digite o valor da cotação do dólar: R$ "); 
            valorcotacao = double.Parse(Console.ReadLine());
            Console.Write("Digite um valor em dólares: US$ ");
            valordolar = double.Parse(Console.ReadLine());
            resultado = valordolar * valorcotacao;
            Console.WriteLine( resultado.ToString("C"));

        }
    }
}
