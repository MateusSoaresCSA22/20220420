﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex_8_Lista
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            double valor; 
            double resultado;
            Console.WriteLine("Exercício 8"); Console.WriteLine("");
            Console.Write("Digite um valor em Graus celsius: "); 
            valor = double.Parse(Console.ReadLine());
            resultado = (valor * 1.8) + 32;
            Console.WriteLine(resultado);




        }
    }
}
