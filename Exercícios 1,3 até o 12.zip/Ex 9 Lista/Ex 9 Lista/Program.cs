﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex_9_Lista
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valor; 
            double resultado;
            Console.WriteLine("Exercício 9"); Console.WriteLine("");
            Console.Write("Digite o Valor do Diâmetro do Circulo: "); 
            valor = double.Parse(Console.ReadLine());
            resultado = Math.PI * Math.Pow((valor / 2), 2);
            Console.WriteLine(resultado);


        }
    }
}
