﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex_6_Lista
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            double valor1;
            double valor2;
            double resultado;
            Console.WriteLine("Exercício 6"); Console.WriteLine("");
            Console.Write("Digite o primeiro valor: ");
            valor1 = double.Parse(Console.ReadLine());
            Console.Write("Digite o segundo valor: "); 
            valor2 = double.Parse(Console.ReadLine());
            resultado = valor1 * valor2; resultado = Math.Sqrt(resultado);
            Console.WriteLine(resultado);

        }
    }
}
