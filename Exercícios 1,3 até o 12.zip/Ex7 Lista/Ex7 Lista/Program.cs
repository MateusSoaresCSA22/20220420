﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex7_Lista
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            double valor;
            double resultado;
            Console.WriteLine("Exercício 7"); Console.WriteLine("");
            Console.Write("Digite um valor em milha marítima: "); 
            valor = double.Parse(Console.ReadLine());
            resultado = valor * 1.852;
            Console.WriteLine( resultado);

        }
    }
}
