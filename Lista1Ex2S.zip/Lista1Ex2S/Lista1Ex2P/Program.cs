﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex2P
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double area;
            double aresta;

            Console.Write("Digite o valor da aresta:");
            aresta = double.Parse(Console.ReadLine());

            area = aresta * aresta;

            Console.WriteLine("A área é igual à {0}", area);

        }
    }
}
