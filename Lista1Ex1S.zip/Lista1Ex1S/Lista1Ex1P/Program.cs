﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex1P
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double b;
            double alt;
            double resul;

            Console.Write("Digite o valor da base:");
            b = double.Parse(Console.ReadLine());

            Console.Write("Digite o valor da altura:");
            alt = double.Parse(Console.ReadLine());

            resul = (b * alt) / 2 ;
            Console.WriteLine("O Resultado da área é {0}", resul);


        }
    }
}
